setwd("C://Users//MSI//Desktop//IT24102941")

# Set seed for reproducibility
set.seed(123)

# Generate a random sample of size 25
baking_time <- rnorm(25, mean = 45, sd = 2)

# Display the sample
baking_time

# Perform one-sample t-test
t_test_result <- t.test(baking_time, mu = 46, alternative = "less")

# Display the full test result
t_test_result

# Extract values
t_statistic <- t_test_result$statistic
p_value <- t_test_result$p.value
conf_interval <- t_test_result$conf.int

# Print results
t_statistic
p_value
conf_interval
