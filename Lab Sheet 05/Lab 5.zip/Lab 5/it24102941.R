# Set working directory
setwd("C://Users//it24102941//Desktop//Lab 5")

# Import dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Renaming the column for easier access
names(Delivery_Times) <- c("x1")

# Attach to access column directly
attach(Delivery_Times)

# Create histogram with right open intervals
histogram <- hist(x1, main = "Delivery Time", breaks = seq(20, 70, length = 9), right = TRUE)

# Cumulative frequency
cum.freq <- cumsum(histogram$counts)

# Round breaks
rounded_breaks <- round(histogram$breaks)

# Create the frequency polygon (Ogive)
plot(rounded_breaks[-1], cum.freq, type = "o", 
     main = "Delivery Time Frequency Polygon", 
     xlab = "Delivery Time", ylab = "Cumulative Frequency", col = "red")

